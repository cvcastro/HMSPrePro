    # Process:  Longest Flowpath
    FDR = os.path.join(temp, "FDR")
    arcpy.AddMessage("Longest Flowpath Processing...")
    arcpy.PolygonToRaster_conversion(in_features=os.path.join(outDir, "Basin"), value_field="HydroID", out_rasterdataset="CATCHM")
    arcpy.gp.FocalStatistics_sa("CATCHM", "RANGE", "Rectangle 3 3 CELL", "RANGE", "DATA")
    arcpy.gp.RasterCalculator_sa("""Con("RANGE" == 0,"CATCHM")""", "ISLANDS")
    arcpy.gp.FlowLength_sa(FDR, "FLEN", "DOWNSTREAM", "")
    arcpy.gp.ZonalStatistics_sa("ISLANDS", "VALUE", "FLEN", "LENMAX", "MAXIMUM", "DATA")
    arcpy.gp.RasterCalculator_sa("""Con("LENMAX" == "FLEN","ISLANDS")""", "MAXPTS")
    arcpy.RasterToPoint_conversion("MAXPTS", "SOURCES", "Value")
    arcpy.DeleteIdentical_management(in_dataset="SOURCES", fields="GRID_CODE", xy_tolerance="", z_tolerance="0")
    arcpy.gp.CostPath_sa("SOURCES", FDR, FDR, "CPATHS", "EACH_CELL", "GRID_CODE")
    arcpy.gp.StreamToFeature_sa("CPATHS", FDR, "Long", "SIMPLIFY")
    arcpy.DeleteIdentical_management(in_dataset="Long", fields="GRID_CODE", xy_tolerance="", z_tolerance="0")

    # Delete extra layers
    arcpy.Delete_management("RANGE")
    arcpy.Delete_management("ISLANDS")
    arcpy.Delete_management("FLEN")
    arcpy.Delete_management("LENMAX")
    arcpy.Delete_management("MAXPTS")
    arcpy.Delete_management("SOURCES")
    arcpy.Delete_management("CPATHS")

    # Project Data
    arcpy.AddMessage("Projecting layers...")
    catchment = arcpy.Project_management(os.path.join(outDir,"Basin"), os.path.join(outDir,"Subbasin"), coords, preserve_shape="NO_PRESERVE_SHAPE", max_deviation="")
    flowline = arcpy.Project_management(os.path.join(outDir,"Flowline"), os.path.join(outDir,"Reach"), coords, preserve_shape="NO_PRESERVE_SHAPE", max_deviation="")
    longest = arcpy.Project_management("Long", os.path.join(outDir,"Longest"), coords, preserve_shape="NO_PRESERVE_SHAPE", max_deviation="")

    # HEC-HMS Basin Map
    arcpy.management.MakeFeatureLayer(catchment,"SubbasinMap")
    arcpy.management.CopyFeatures("SubbasinMap",os.path.join(temp,"basinmap.shp"))
    arcpy.management.Delete("SubbasinMap")

    # Field Management
    arcpy.AddMessage("Updating ArcHydro Fields...")
    arcpy.AddField_management(flowline, "FTYPE", "STRING", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    arcpy.gp.ZonalStatistics_sa(longest, "OBJECTID", "CATCHM", "ZONAL", "MAJORITY", "DATA")
    arcpy.RasterToPolyline_conversion("ZONAL", os.path.join(outDir,"Longest"), "ZERO", "0", "SIMPLIFY", "Value")
    arcpy.DeleteIdentical_management(os.path.join(outDir,"Longest"), fields="grid_code", xy_tolerance="", z_tolerance="0")

    with arcpy.da.UpdateCursor(flowline, ["FTYPE"]) as cursor:
        for row in cursor:
            row[0] = 'StreamRiver'
            cursor.updateRow(row)

    GridID = {}
    HydroIDs = []
    with arcpy.da.SearchCursor(flowline, ["HydroID", "GridID"]) as cursor:
        for row in cursor:
            GridID[row[0]] = row[1]
            HydroIDs.append(row[0])

    with arcpy.da.UpdateCursor(flowline, ["NextDownID"]) as cursor:
        for row in cursor:
            if row[0] in HydroIDs:
                row[0] = GridID[row[0]]
            else:
                row[0] = 0
            cursor.updateRow(row)